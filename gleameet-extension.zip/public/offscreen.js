"use strict";
(() => {
  // src/offscreen.ts
  var micRecorder = null;
  var micInterval = null;
  var micSessionId = null;
  var tabRecorder = null;
  var tabInterval = null;
  var tabAudioCtx = null;
  var tabSessionId = null;
  var expectedRecorderStops = /* @__PURE__ */ new WeakSet();
  chrome.runtime.onMessage.addListener(async (message) => {
    if (message.type === "START_MIC_CAPTURE") {
      const { meetingSessionId, sessionToken, apiBase } = message;
      if (micRecorder && micSessionId === meetingSessionId && isRecorderHealthy(micRecorder)) {
        return;
      }
      stopMicCapture();
      navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          // Don't interfere with meeting's echo cancellation
          noiseSuppression: false,
          autoGainControl: false
        }
      }).then((stream) => {
        const { recorder, interval } = startRecording(stream, "mic", meetingSessionId, sessionToken, apiBase, (nextRecorder) => {
          if (micSessionId === meetingSessionId) micRecorder = nextRecorder;
        });
        micRecorder = recorder;
        micInterval = interval;
        micSessionId = meetingSessionId;
        console.log("[GleaMeet Offscreen] Mic capture started");
      }).catch((err) => {
        console.warn("[GleaMeet Offscreen] Mic capture failed:", err.message);
      });
    }
    if (message.type === "START_TAB_CAPTURE") {
      const { meetingSessionId, sessionToken, apiBase, streamId } = message;
      if (tabRecorder && tabSessionId === meetingSessionId && isRecorderHealthy(tabRecorder)) {
        return;
      }
      stopTabCapture();
      navigator.mediaDevices.getUserMedia({
        audio: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: streamId
          }
        },
        video: false
      }).then((tabStream) => {
        const audioCtx = new AudioContext();
        tabAudioCtx = audioCtx;
        const source = audioCtx.createMediaStreamSource(tabStream);
        source.connect(audioCtx.destination);
        const dest = audioCtx.createMediaStreamDestination();
        source.connect(dest);
        const { recorder, interval } = startRecording(dest.stream, "tab", meetingSessionId, sessionToken, apiBase, (nextRecorder) => {
          if (tabSessionId === meetingSessionId) tabRecorder = nextRecorder;
        });
        tabRecorder = recorder;
        tabInterval = interval;
        tabSessionId = meetingSessionId;
        console.log("[GleaMeet Offscreen] Tab audio split: speakers + recorder both active");
      }).catch((err) => {
        console.warn("[GleaMeet Offscreen] Tab capture failed:", err.message);
      });
    }
    if (message.type === "STOP_MIC_CAPTURE") {
      stopMicCapture();
      console.log("[GleaMeet Offscreen] Mic capture stopped");
    }
    if (message.type === "STOP_TAB_CAPTURE") {
      stopTabCapture();
      console.log("[GleaMeet Offscreen] Tab capture stopped");
    }
  });
  function isRecorderHealthy(recorder) {
    return recorder.state === "recording" && recorder.stream.active && recorder.stream.getAudioTracks().some((track) => track.readyState === "live");
  }
  function stopMicCapture() {
    if (micInterval) {
      clearInterval(micInterval);
      micInterval = null;
    }
    if (micRecorder) {
      expectedRecorderStops.add(micRecorder);
      if (micRecorder.state === "recording") {
        try {
          micRecorder.stop();
        } catch (_) {
        }
      }
      micRecorder.stream.getTracks().forEach((t) => t.stop());
      micRecorder = null;
    }
    micSessionId = null;
  }
  function stopTabCapture() {
    if (tabInterval) {
      clearInterval(tabInterval);
      tabInterval = null;
    }
    if (tabRecorder) {
      expectedRecorderStops.add(tabRecorder);
      if (tabRecorder.state === "recording") {
        try {
          tabRecorder.stop();
        } catch (_) {
        }
      }
      tabRecorder.stream.getTracks().forEach((t) => t.stop());
      tabRecorder = null;
    }
    if (tabAudioCtx) {
      tabAudioCtx.close().catch(() => {
      });
      tabAudioCtx = null;
    }
    tabSessionId = null;
  }
  function startRecording(stream, streamType, meetingSessionId, sessionToken, apiBase, onRecorderChange) {
    let recorder = null;
    let chunkStartedAt = Date.now();
    let chunkStopInProgress = false;
    let stopReported = false;
    let interval = null;
    let lastTranscriptTextAt = Date.now();
    let chunksSinceText = 0;
    let consecutiveUploadFailures = 0;
    let consecutiveEmptyTranscripts = 0;
    let consecutiveTinyChunks = 0;
    let lastDataAvailableAt = Date.now();
    const makeRecorder = () => {
      const preferredMimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
      return new MediaRecorder(stream, { mimeType: preferredMimeType });
    };
    const reportUnexpectedStop = (reason) => {
      if (stopReported || recorder && expectedRecorderStops.has(recorder)) return;
      stopReported = true;
      if (interval) {
        clearInterval(interval);
        interval = null;
      }
      chrome.runtime.sendMessage({
        type: "AUDIO_CAPTURE_STOPPED",
        stream: streamType,
        meetingSessionId,
        reason
      }).catch(() => {
      });
      try {
        if (recorder?.state === "recording") recorder.stop();
      } catch (_) {
      }
      stream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (_) {
        }
      });
    };
    stream.getAudioTracks().forEach((track) => {
      track.addEventListener("ended", () => reportUnexpectedStop("track-ended"));
      track.addEventListener("mute", () => {
        setTimeout(() => {
          if (track.muted && recorder?.state === "recording") {
            reportUnexpectedStop("track-muted");
          }
        }, 3e4);
      });
    });
    const uploadChunk = async (blob, chunkStart, chunkEndedAt) => {
      if (!blob || blob.size < 1e3) {
        consecutiveTinyChunks++;
        chunksSinceText++;
        if (consecutiveTinyChunks >= 12 && chunksSinceText >= 12 && Date.now() - lastTranscriptTextAt > 12e4) {
          reportUnexpectedStop("audio-chunks-too-small");
        }
        return;
      }
      consecutiveTinyChunks = 0;
      const form = new FormData();
      form.append("audio", blob, "chunk.webm");
      form.append("stream", streamType);
      form.append("meeting_session_id", meetingSessionId);
      const response = await fetch(`${apiBase}/audio/transcribe`, {
        method: "POST",
        headers: { Authorization: `Bearer ${sessionToken}` },
        body: form
      }).catch(() => null);
      if (!response?.ok) {
        consecutiveUploadFailures++;
        if (consecutiveUploadFailures >= 3) {
          reportUnexpectedStop("transcription-upload-failed");
        }
        return;
      }
      consecutiveUploadFailures = 0;
      const result = await response.json().catch(() => null);
      if (!result?.text) {
        consecutiveEmptyTranscripts++;
        chunksSinceText++;
        if (consecutiveEmptyTranscripts >= 6 && chunksSinceText >= 6 && Date.now() - lastTranscriptTextAt > 6e4) {
          reportUnexpectedStop("transcription-stalled");
        }
        return;
      }
      consecutiveEmptyTranscripts = 0;
      consecutiveTinyChunks = 0;
      chunksSinceText = 0;
      lastTranscriptTextAt = Date.now();
      chrome.runtime.sendMessage({
        type: "AUDIO_TRANSCRIPT_RESULT",
        text: result.text,
        stream: streamType,
        startOffsetMs: chunkStart,
        endOffsetMs: chunkEndedAt,
        eventTimeMs: chunkEndedAt
      }).catch(() => {
      });
    };
    const startChunkRecorder = () => {
      if (stopReported || !stream.active || !stream.getAudioTracks().some((track) => track.readyState === "live")) {
        reportUnexpectedStop("stream-ended");
        return;
      }
      const nextRecorder = makeRecorder();
      recorder = nextRecorder;
      onRecorderChange?.(nextRecorder);
      const chunks = [];
      chunkStartedAt = Date.now();
      nextRecorder.onerror = () => reportUnexpectedStop("recorder-error");
      nextRecorder.ondataavailable = (e) => {
        lastDataAvailableAt = Date.now();
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };
      nextRecorder.onstop = () => {
        if (expectedRecorderStops.has(nextRecorder)) return;
        if (!chunkStopInProgress) {
          reportUnexpectedStop("recorder-stopped");
          return;
        }
        chunkStopInProgress = false;
        const chunkStart = chunkStartedAt;
        const chunkEndedAt = Date.now();
        const blob = new Blob(chunks, { type: nextRecorder.mimeType || "audio/webm" });
        const shouldContinue = !stopReported && stream.active && stream.getAudioTracks().some((track) => track.readyState === "live");
        if (shouldContinue) {
          startChunkRecorder();
        }
        uploadChunk(blob, chunkStart, chunkEndedAt).catch(() => {
          consecutiveUploadFailures++;
          if (consecutiveUploadFailures >= 3) {
            reportUnexpectedStop("transcription-upload-failed");
          }
        });
      };
      try {
        nextRecorder.start();
      } catch (_) {
        reportUnexpectedStop("recorder-start-failed");
      }
    };
    startChunkRecorder();
    interval = setInterval(() => {
      const liveAudioTrack = stream.getAudioTracks().some((track) => track.readyState === "live");
      if (!recorder || recorder.state !== "recording" || !stream.active || !liveAudioTrack) {
        reportUnexpectedStop("health-check-failed");
        return;
      }
      if (Date.now() - lastDataAvailableAt > 12e4) {
        reportUnexpectedStop("no-audio-chunks");
        return;
      }
      try {
        chunkStopInProgress = true;
        recorder.stop();
      } catch (_) {
        chunkStopInProgress = false;
        reportUnexpectedStop("chunk-stop-failed");
      }
    }, 1e4);
    if (!recorder) {
      throw new Error("Audio recorder failed to start");
    }
    return { recorder, interval };
  }
})();
