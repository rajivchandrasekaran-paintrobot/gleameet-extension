const DEFAULT_BACKEND_URL = 'https://gleameet-backend.onrender.com';
const LEGACY_DEFAULT_BACKEND_URL = 'https://gleameet.onrender.com';

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('backendUrl');
  const saveBtn = document.getElementById('save');
  const status = document.getElementById('status');

  // Load saved URL
  chrome.storage.sync.get({ backendUrl: DEFAULT_BACKEND_URL }, (items) => {
    const storedBackendUrl = typeof items.backendUrl === 'string' ? items.backendUrl.trim() : '';
    const backendUrl = !storedBackendUrl || storedBackendUrl === LEGACY_DEFAULT_BACKEND_URL
      ? DEFAULT_BACKEND_URL
      : storedBackendUrl;

    if (storedBackendUrl === LEGACY_DEFAULT_BACKEND_URL) {
      chrome.storage.sync.set({ backendUrl });
    }

    input.value = backendUrl;
  });

  saveBtn.addEventListener('click', () => {
    let url = input.value.trim();
    // Remove trailing slash
    if (url.endsWith('/')) url = url.slice(0, -1);
    if (!url) url = DEFAULT_BACKEND_URL;

    chrome.storage.sync.set({ backendUrl: url }, () => {
      status.textContent = 'Saved!';
      setTimeout(() => { status.textContent = ''; }, 2000);
    });
  });
});
