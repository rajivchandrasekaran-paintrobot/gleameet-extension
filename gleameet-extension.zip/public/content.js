"use strict";
(() => {
  // src/utils/event-factory.ts
  function generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === "x" ? r : r & 3 | 8;
      return v.toString(16);
    });
  }
  function createEvent(meetingSessionId, userId, eventType, payload, captureConfidence = null) {
    return {
      event_id: generateUUID(),
      meeting_session_id: meetingSessionId,
      user_id: userId,
      platform: "google_meet",
      event_type: eventType,
      event_time_utc: (/* @__PURE__ */ new Date()).toISOString(),
      source: "extension",
      capture_confidence: captureConfidence,
      payload
    };
  }

  // src/content/content-script.ts
  var state = {
    meetingDetected: false,
    meetingSessionId: null,
    userId: null,
    status: "off",
    currentPrompt: null,
    promptDismissTimer: null,
    mutationObserver: null,
    speechObserver: null,
    captionObserver: null,
    userSpeaking: false,
    lastSpeechEmitMs: 0,
    eventsEmitted: 0,
    diagnosticInterval: null,
    audioRecorder: null,
    audioInterval: null
  };
  var CAPTION_SELECTORS = [
    // 2025/2026 Meet caption area — the bottom overlay with live text
    '[jsname="tgaKEf"]',
    // Caption text node
    'div[class*="TBMuR"]',
    // Caption container
    'div[class*="CNusmb"]',
    // Caption block
    "div.a4cQT",
    // Captions wrapper
    // Speaker + text containers
    "[data-message-id]",
    // Timestamped captions
    // Fallbacks
    '[jscontroller="D1tHje"] span',
    'div[class*="iOzk7"] span'
  ];
  var SPEECH_THROTTLE_MS = 500;
  function getPlatform() {
    const url = window.location.href;
    if (url.includes("teams.microsoft.com") || url.includes("teams.live.com")) return "teams";
    if (url.includes("zoom.us") || url.includes("app.zoom.us")) return "zoom";
    return "google_meet";
  }
  function detectMeeting() {
    const url = window.location.href;
    if (/meet\.google\.com\/[a-z]+-[a-z]+-[a-z]+/i.test(url)) {
      const hasVideo = !!document.querySelector("video");
      const hasLeaveBtn = !!document.querySelector("[data-is-muted]") || !!document.querySelector('[aria-label*="Leave"]') || !!document.querySelector('[aria-label*="leave"]');
      return hasVideo || hasLeaveBtn;
    }
    if (url.includes("teams.microsoft.com") || url.includes("teams.live.com")) {
      return !!document.querySelector('[data-tid="calling-screen"]') || !!document.querySelector('[data-tid="hangup-btn"]') || !!document.querySelector('button[aria-label*="Leave"]') || !!document.querySelector('button[aria-label*="leave"]') || !!document.querySelector("video");
    }
    if (url.includes("zoom.us/wc") || url.includes("app.zoom.us/wc")) {
      return !!document.querySelector(".meeting-app") || !!document.querySelector("#wc-container-right") || !!document.querySelector("video");
    }
    return false;
  }
  var meetingEndDebounceTimer = null;
  function startMeetingDetection() {
    if (detectMeeting() && !state.meetingDetected) {
      onMeetingDetected();
    }
    state.mutationObserver = new MutationObserver(() => {
      const inMeeting = detectMeeting();
      if (inMeeting && !state.meetingDetected) {
        if (meetingEndDebounceTimer) {
          clearTimeout(meetingEndDebounceTimer);
          meetingEndDebounceTimer = null;
        }
        onMeetingDetected();
      } else if (!inMeeting && state.meetingDetected) {
        if (!meetingEndDebounceTimer) {
          meetingEndDebounceTimer = setTimeout(() => {
            meetingEndDebounceTimer = null;
            if (!detectMeeting()) {
              onMeetingEnded();
            }
          }, 3e3);
        }
      }
    });
    state.mutationObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  function onMeetingDetected() {
    state.meetingDetected = true;
    state.status = "ready";
    chrome.runtime.sendMessage({ type: "MEETING_DETECTED", platform: getPlatform() }).catch(() => {
    });
    injectStatusIndicator();
    console.log("[GleaMeet] Meeting detected");
  }
  function onMeetingEnded() {
    state.meetingDetected = false;
    if (state.status === "active") {
      chrome.runtime.sendMessage({ type: "STOP_COACHING" }).catch(() => {
      });
    }
    state.status = "off";
    state.meetingSessionId = null;
    stopAudioCapture();
    if (state.speechObserver) {
      state.speechObserver.disconnect();
      state.speechObserver = null;
    }
    if (state.captionObserver) {
      state.captionObserver.disconnect();
      state.captionObserver = null;
    }
    if (state.diagnosticInterval) {
      clearInterval(state.diagnosticInterval);
      state.diagnosticInterval = null;
    }
    removeOverlay();
    removeStatusIndicator();
    console.log("[GleaMeet] Meeting ended");
  }
  function startSignalCapture() {
    if (!state.meetingSessionId || !state.userId) return;
    const platform = getPlatform();
    if (platform === "google_meet") {
      observeSpeechIndicators();
      observeCaptions();
    } else {
      console.log(`[GleaMeet] ${platform}: using mic-only Whisper transcription`);
      startMicrophoneDetection();
    }
    startAudioCapture(state.meetingSessionId);
    emitEvent("session_state_changed", {
      previous_state: "ready",
      new_state: "active",
      reason: "coaching_enabled",
      platform
    });
    state.diagnosticInterval = setInterval(() => {
      const captionEls = platform === "google_meet" ? CAPTION_SELECTORS.flatMap((sel) => Array.from(document.querySelectorAll(sel))).length : 0;
      console.log(`[GleaMeet] Diagnostics [${platform}]: events_emitted=${state.eventsEmitted}, speech_active=${state.userSpeaking}, recognition_running=${!!recognition}, caption_elements_found=${captionEls}`);
    }, 1e4);
  }
  function observeSpeechIndicators() {
    if (state.speechObserver) {
      state.speechObserver.disconnect();
    }
    startMicrophoneDetection();
    state.speechObserver = new MutationObserver(() => {
    });
    state.speechObserver.observe(document.body, { childList: true, subtree: false });
  }
  var recognition = null;
  function startMicrophoneDetection() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("[GleaMeet] SpeechRecognition not available");
      return;
    }
    function startRecognition() {
      recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      recognition.onstart = () => {
        console.log("[GleaMeet] Speech recognition active");
      };
      recognition.onspeechstart = () => {
        const now = Date.now();
        if (!state.userSpeaking && now - state.lastSpeechEmitMs > SPEECH_THROTTLE_MS) {
          state.userSpeaking = true;
          state.lastSpeechEmitMs = now;
          emitEvent("speech_started", { speaker: "user", offset_ms: now }, 0.9);
        }
      };
      recognition.onspeechend = () => {
        const now = Date.now();
        if (state.userSpeaking) {
          state.userSpeaking = false;
          state.lastSpeechEmitMs = now;
          emitEvent("speech_ended", { speaker: "user", offset_ms: now }, 0.9);
        }
      };
      recognition.onresult = (event) => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const text = result[0].transcript.trim();
          if (!text) continue;
          if (result.isFinal && !whisperActive) {
            emitEvent("transcript_segment", {
              text,
              speaker: "user",
              start_offset_ms: Date.now(),
              end_offset_ms: Date.now()
            }, 0.9);
          }
        }
      };
      recognition.onerror = (event) => {
        if (event.error === "no-speech") return;
        console.warn("[GleaMeet] Speech recognition error:", event.error);
        if (["audio-capture", "network", "aborted"].includes(event.error)) {
          setTimeout(() => {
            try {
              startRecognition();
            } catch (e) {
            }
          }, 1e3);
        }
      };
      recognition.onend = () => {
        setTimeout(() => {
          try {
            startRecognition();
          } catch (e) {
            setTimeout(() => {
              try {
                startRecognition();
              } catch (_) {
              }
            }, 3e3);
          }
        }, 1e3);
      };
      try {
        recognition.start();
      } catch (e) {
        console.warn("[GleaMeet] Could not start speech recognition:", e);
      }
    }
    startRecognition();
  }
  function observeCaptions() {
    if (state.captionObserver) {
      state.captionObserver.disconnect();
    }
    state.captionObserver = new MutationObserver(() => {
      const seen = /* @__PURE__ */ new Set();
      for (const selector of CAPTION_SELECTORS) {
        try {
          document.querySelectorAll(selector).forEach((el) => seen.add(el));
        } catch (e) {
        }
      }
      for (const el of seen) {
        const text = el.textContent?.trim();
        if (!text || text.length < 10 || el.getAttribute("data-gleameet-captured")) continue;
        if (/^[A-Z][a-zA-Z\s,]+\([A-Z][a-zA-Z\s]+\)$/.test(text)) continue;
        const wordCount = text.split(/\s+/).filter((w) => w.length > 0).length;
        if (wordCount < 5) continue;
        el.setAttribute("data-gleameet-captured", "1");
        const container = el.closest("[class]");
        const containerText = container?.previousElementSibling?.textContent?.trim() || "";
        const isSelf = containerText === "You" || !!el.closest("[data-self-name]") || !!el.closest('[data-is-self="true"]');
        const speaker = isSelf ? "user" : "other";
        if (whisperActive) continue;
        console.log(`[GleaMeet] Caption captured (${speaker}): ${text.slice(0, 80)}`);
        emitEvent("transcript_segment", {
          text,
          speaker,
          start_offset_ms: Date.now(),
          end_offset_ms: Date.now()
        }, 0.3);
      }
    });
    state.captionObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  function emitEvent(eventType, payload, captureConfidence = null) {
    if (!state.meetingSessionId || !state.userId) return;
    state.eventsEmitted++;
    const event = createEvent(
      state.meetingSessionId,
      state.userId,
      eventType,
      payload,
      captureConfidence
    );
    chrome.runtime.sendMessage({ type: "INGEST_EVENT", event }).catch(() => {
    });
  }
  var DEFAULT_API_BASE = "https://gleameet.onrender.com";
  async function getApiBase() {
    return new Promise((resolve) => {
      chrome.storage.sync.get({ backendUrl: DEFAULT_API_BASE }, (items) => {
        resolve(items.backendUrl || DEFAULT_API_BASE);
      });
    });
  }
  async function getStoredToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["sessionToken"], (data) => {
        resolve(data.sessionToken || null);
      });
    });
  }
  var whisperActive = false;
  function startAudioCapture(meetingSessionId) {
    navigator.mediaDevices.getUserMedia({ audio: true }).then((micStream) => {
      whisperActive = true;
      const recorder = new MediaRecorder(micStream, { mimeType: "audio/webm" });
      let chunks = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: "audio/webm" });
        chunks = [];
        if (blob.size < 1e3) return;
        try {
          const [apiBase, token] = await Promise.all([getApiBase(), getStoredToken()]);
          const formData = new FormData();
          formData.append("audio", blob, "chunk.webm");
          formData.append("stream", "mic");
          formData.append("meeting_session_id", meetingSessionId);
          const headers = {};
          if (token) headers["Authorization"] = `Bearer ${token}`;
          const response = await fetch(`${apiBase}/audio/transcribe`, {
            method: "POST",
            headers,
            body: formData
          });
          if (!response.ok) {
            console.error("[GleaMeet] Whisper API error:", response.status);
            return;
          }
          const { text } = await response.json();
          if (text?.trim()) {
            emitEvent("transcript_segment", {
              text: text.trim(),
              speaker: "user",
              start_offset_ms: Date.now(),
              end_offset_ms: Date.now()
            }, 0.9);
          }
        } catch (err) {
          console.error("[GleaMeet] Whisper transcription failed (mic):", err);
        }
      };
      recorder.start();
      state.audioRecorder = recorder;
      state.audioInterval = setInterval(() => {
        if (recorder.state === "recording") {
          recorder.stop();
          recorder.start();
        }
      }, 1e4);
      console.log("[GleaMeet] Mic audio capture started (content script)");
    }).catch((e) => {
      console.warn("[GleaMeet] Mic capture failed:", e);
    });
  }
  function stopAudioCapture() {
    if (state.audioInterval) {
      clearInterval(state.audioInterval);
      state.audioInterval = null;
    }
    if (state.audioRecorder) {
      if (state.audioRecorder.state === "recording") {
        try {
          state.audioRecorder.stop();
        } catch (_) {
        }
      }
      state.audioRecorder.stream.getTracks().forEach((t) => t.stop());
      state.audioRecorder = null;
    }
  }
  function createOverlay() {
    let overlay = document.getElementById("gleameet-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "gleameet-overlay";
      document.body.appendChild(overlay);
    }
    return overlay;
  }
  function removeOverlay() {
    const overlay = document.getElementById("gleameet-overlay");
    if (overlay) overlay.remove();
  }
  function showPrompt(prompt) {
    dismissCurrentPrompt();
    state.currentPrompt = prompt;
    const overlay = createOverlay();
    const promptEl = document.createElement("div");
    promptEl.className = "gleameet-prompt";
    promptEl.setAttribute("data-prompt-id", prompt.prompt_id);
    const header = document.createElement("div");
    header.className = "gleameet-prompt-header";
    const label = document.createElement("span");
    label.className = "gleameet-prompt-label";
    label.textContent = `Coach \xB7 ${prompt.prompt_type}`;
    const lawCode = document.createElement("span");
    lawCode.className = "gleameet-prompt-law-code";
    lawCode.textContent = prompt.law_id;
    lawCode.title = `Law: ${prompt.law_id}`;
    const dismissBtn = document.createElement("button");
    dismissBtn.className = "gleameet-prompt-dismiss";
    dismissBtn.textContent = "\xD7";
    dismissBtn.title = "Dismiss";
    dismissBtn.addEventListener("click", () => dismissPrompt(prompt.prompt_id));
    header.appendChild(label);
    header.appendChild(lawCode);
    header.appendChild(dismissBtn);
    const text = document.createElement("div");
    text.className = "gleameet-prompt-text";
    text.textContent = prompt.short_text;
    promptEl.appendChild(header);
    promptEl.appendChild(text);
    if (prompt.rationale_text) {
      const rationale = document.createElement("div");
      rationale.className = "gleameet-prompt-rationale";
      rationale.textContent = prompt.rationale_text;
      promptEl.appendChild(rationale);
    }
    overlay.innerHTML = "";
    overlay.appendChild(promptEl);
    ackPrompt(prompt.prompt_id, "shown");
    state.promptDismissTimer = setTimeout(() => {
      dismissPrompt(prompt.prompt_id);
    }, 15e3);
  }
  function dismissCurrentPrompt() {
    if (state.currentPrompt) {
      dismissPrompt(state.currentPrompt.prompt_id);
    }
  }
  function dismissPrompt(promptId) {
    const overlay = document.getElementById("gleameet-overlay");
    if (overlay) {
      const el = overlay.querySelector(`[data-prompt-id="${promptId}"]`);
      if (el) el.remove();
    }
    if (state.promptDismissTimer) {
      clearTimeout(state.promptDismissTimer);
      state.promptDismissTimer = null;
    }
    if (state.currentPrompt?.prompt_id === promptId) {
      ackPrompt(promptId, "dismissed");
      state.currentPrompt = null;
    }
  }
  function ackPrompt(promptId, action) {
    chrome.runtime.sendMessage({
      type: "ACK_PROMPT",
      promptId,
      meetingSessionId: state.meetingSessionId,
      action
    }).catch(() => {
    });
  }
  function injectStatusIndicator() {
    removeStatusIndicator();
    const indicator = document.createElement("div");
    indicator.id = "gleameet-status";
    indicator.className = `gleameet-status ${state.status}`;
    const dot = document.createElement("span");
    dot.className = "gleameet-status-dot";
    const label = document.createElement("span");
    label.textContent = `GleaMeet: ${state.status}`;
    indicator.appendChild(dot);
    indicator.appendChild(label);
    document.body.appendChild(indicator);
  }
  function removeStatusIndicator() {
    const indicator = document.getElementById("gleameet-status");
    if (indicator) indicator.remove();
  }
  function updateStatusIndicator() {
    const indicator = document.getElementById("gleameet-status");
    if (indicator) {
      indicator.className = `gleameet-status ${state.status}`;
      const label = indicator.querySelector("span:last-child");
      if (label) label.textContent = `GleaMeet: ${state.status}`;
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message.type) {
      case "STATUS_UPDATE":
        state.status = message.status;
        state.meetingSessionId = message.meetingSessionId;
        updateStatusIndicator();
        break;
      case "SHOW_PROMPT":
        if (state.status === "active") {
          showPrompt(message.prompt);
        }
        break;
      case "COACHING_STARTED":
        state.meetingSessionId = message.meetingSessionId;
        state.userId = message.userId;
        state.status = "active";
        updateStatusIndicator();
        startSignalCapture();
        startAudioCapture(message.meetingSessionId);
        break;
      case "DISMISS_ALL_PROMPTS":
        dismissCurrentPrompt();
        break;
    }
    sendResponse({ ok: true });
    return true;
  });
  function showConsentDialog() {
    return new Promise((resolve) => {
      const backdrop = document.createElement("div");
      backdrop.id = "gleameet-consent-backdrop";
      backdrop.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(0,0,0,0.5); display: flex;
      align-items: center; justify-content: center;
    `;
      const dialog = document.createElement("div");
      dialog.style.cssText = `
      background: white; border-radius: 12px; padding: 24px;
      max-width: 420px; width: 90%; font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    `;
      dialog.innerHTML = `
      <h2 style="margin: 0 0 12px; font-size: 18px; color: #1a1a2e;">Enable Meeting Coach</h2>
      <p style="margin: 0 0 8px; font-size: 13px; color: #6b6b80; line-height: 1.5;">
        GleaMeet will privately coach you during this meeting. By enabling:
      </p>
      <ul style="margin: 0 0 16px; padding-left: 20px; font-size: 13px; color: #6b6b80; line-height: 1.6;">
        <li>Coaching is <strong>private to you only</strong></li>
        <li>Meeting timing and conversation signals will be captured</li>
        <li>Live prompts may appear during the meeting</li>
        <li>You can mute or stop coaching at any time</li>
        <li>You can delete meeting data after the session</li>
      </ul>
      <div style="display: flex; gap: 8px; justify-content: flex-end;">
        <button id="gleameet-consent-cancel" style="
          padding: 8px 16px; border: 1px solid #e0e0e8; border-radius: 6px;
          background: white; color: #6b6b80; cursor: pointer; font-size: 13px;
        ">Not Now</button>
        <button id="gleameet-consent-accept" style="
          padding: 8px 16px; border: none; border-radius: 6px;
          background: #0066cc; color: white; cursor: pointer; font-size: 13px; font-weight: 500;
        ">Enable Coaching</button>
      </div>
    `;
      backdrop.appendChild(dialog);
      document.body.appendChild(backdrop);
      document.getElementById("gleameet-consent-accept").addEventListener("click", () => {
        backdrop.remove();
        resolve(true);
      });
      document.getElementById("gleameet-consent-cancel").addEventListener("click", () => {
        backdrop.remove();
        resolve(false);
      });
    });
  }
  window.__gleameet_showConsent = showConsentDialog;
  startMeetingDetection();
})();
