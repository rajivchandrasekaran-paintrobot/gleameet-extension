// src/utils/api-client.ts
var DEFAULT_API_BASE = "https://gleameet.onrender.com";
var LEGACY_DEFAULT_API_BASE = "https://gleameet.onrender.com";
async function getApiBase() {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.sync) {
      chrome.storage.sync.get({ backendUrl: DEFAULT_API_BASE }, (items) => {
        const storedBackendUrl = typeof items.backendUrl === "string" ? items.backendUrl.trim() : "";
        if (!storedBackendUrl || storedBackendUrl === LEGACY_DEFAULT_API_BASE) {
          if (storedBackendUrl === LEGACY_DEFAULT_API_BASE) {
            chrome.storage.sync.set({ backendUrl: DEFAULT_API_BASE });
          }
          resolve(DEFAULT_API_BASE);
          return;
        }
        resolve(storedBackendUrl);
      });
    } else {
      resolve(DEFAULT_API_BASE);
    }
  });
}
var sessionToken = null;
function getHeaders() {
  const headers = { "Content-Type": "application/json" };
  if (sessionToken) {
    headers["Authorization"] = `Bearer ${sessionToken}`;
  }
  return headers;
}
async function refreshSessionIfNeeded() {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.identity) {
      resolve();
      return;
    }
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      if (!token || chrome.runtime.lastError) {
        resolve();
        return;
      }
      createSession(token).then(() => resolve()).catch(() => resolve());
    });
  });
}
async function apiRequest(method, path, body, retry = true) {
  const apiBase = await getApiBase();
  const response = await fetch(`${apiBase}${path}`, {
    method,
    headers: getHeaders(),
    body: body ? JSON.stringify(body) : void 0
  });
  if (response.status === 401 && retry) {
    await refreshSessionIfNeeded();
    return apiRequest(method, path, body, false);
  }
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Unknown error" }));
    throw new Error(error.error || `API error: ${response.status}`);
  }
  return response.json();
}
async function createSession(googleIdToken) {
  const result = await apiRequest("POST", "/auth/session", {
    google_id_token: googleIdToken
  });
  sessionToken = result.session_token;
  return result;
}
async function startMeeting(request) {
  return apiRequest("POST", "/meetings/start", request);
}
async function sendEventBatch(request) {
  return apiRequest("POST", "/events/batch", request);
}
async function pollPrompts(meetingSessionId) {
  return apiRequest("GET", `/prompts/poll?meeting_session_id=${meetingSessionId}`);
}
async function ackPrompt(request) {
  return apiRequest("POST", "/prompts/ack", request);
}
async function endMeeting(meetingSessionId) {
  return apiRequest("POST", "/meetings/end", {
    meeting_session_id: meetingSessionId
  });
}
function setSessionToken(token) {
  sessionToken = token;
}
function getSessionToken() {
  return sessionToken;
}

// src/utils/platform.ts
var MEETING_TAB_URL_PATTERNS = [
  "https://meet.google.com/*",
  "https://teams.microsoft.com/*",
  "https://teams.live.com/*",
  "https://zoom.us/wc/*",
  "https://app.zoom.us/wc/*"
];
function detectPlatformFromUrl(url) {
  if (url.includes("meet.google.com")) return "google_meet";
  if (url.includes("teams.microsoft.com") || url.includes("teams.live.com")) return "teams";
  if (url.includes("zoom.us") || url.includes("app.zoom.us")) return "zoom";
  return null;
}

// src/background/service-worker.ts
var state = {
  meetingDetected: false,
  meetingSessionId: null,
  userId: null,
  platform: null,
  status: "off",
  eventBuffer: []
};
var POLL_ALARM = "prompt-poll";
var FLUSH_ALARM = "event-flush";
var SESSION_STATE_KEY = "gleameetSessionState";
function persistSessionState() {
  chrome.storage.local.set({
    [SESSION_STATE_KEY]: {
      meetingDetected: state.meetingDetected,
      meetingSessionId: state.meetingSessionId,
      userId: state.userId,
      platform: state.platform,
      status: state.status
    }
  });
}
function restoreTimersForState() {
  chrome.alarms.clear(POLL_ALARM);
  chrome.alarms.clear(FLUSH_ALARM);
  if (state.meetingSessionId && state.status === "active") {
    chrome.alarms.create(POLL_ALARM, { periodInMinutes: 2 / 60 });
    chrome.alarms.create(FLUSH_ALARM, { periodInMinutes: 3 / 60 });
  }
}
function clearRuntimeScheduling() {
  chrome.alarms.clear(POLL_ALARM);
  chrome.alarms.clear(FLUSH_ALARM);
}
chrome.storage.local.get(["sessionToken", "userId", SESSION_STATE_KEY], (data) => {
  if (data.sessionToken) {
    setSessionToken(data.sessionToken);
    state.userId = data.userId || null;
  }
  const saved = data[SESSION_STATE_KEY];
  if (saved && typeof saved === "object") {
    state.meetingDetected = !!saved.meetingDetected;
    state.meetingSessionId = saved.meetingSessionId || null;
    state.userId = saved.userId || state.userId;
    state.platform = saved.platform || null;
    state.status = saved.status || "off";
    restoreTimersForState();
  }
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) {
    pollForPrompts().catch((err) => console.error("[GleaMeet] Prompt poll alarm failed:", err));
  }
  if (alarm.name === FLUSH_ALARM) {
    flushEventBuffer().catch((err) => console.error("[GleaMeet] Flush alarm failed:", err));
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch((err) => sendResponse({ error: err.message }));
  return true;
});
async function handleMessage(message) {
  switch (message.type) {
    case "MEETING_DETECTED":
      state.meetingDetected = true;
      state.platform = message.platform || state.platform;
      if (state.status === "off") {
        state.status = "ready";
      }
      persistSessionState();
      broadcastStatus();
      return { status: "ready" };
    case "MEETING_ENDED":
      return handleMeetingEnded();
    case "START_COACHING":
      if (state.meetingSessionId) {
        state.status = "active";
        restoreTimersForState();
        persistSessionState();
        broadcastStatus();
        chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
          for (const tab of tabs) {
            if (tab.id) {
              chrome.tabs.sendMessage(tab.id, {
                type: "COACHING_STARTED",
                meetingSessionId: state.meetingSessionId,
                userId: state.userId,
                platform: state.platform
              }).catch(() => {
              });
            }
          }
        });
        return { status: "active", meetingSessionId: state.meetingSessionId, resumed: true };
      }
      return handleStartCoaching(message);
    case "STOP_COACHING":
      return handlePauseCoaching();
    case "END_MEETING":
      return handleStopCoaching();
    case "MUTE_COACHING":
      state.status = "muted";
      persistSessionState();
      broadcastStatus();
      return { status: "muted" };
    case "UNMUTE_COACHING":
      state.status = "active";
      restoreTimersForState();
      persistSessionState();
      broadcastStatus();
      return { status: "active" };
    case "INGEST_EVENT":
      if (state.status === "active" && message.event) {
        state.eventBuffer.push(message.event);
      }
      return { buffered: true };
    case "GET_STATUS":
      return {
        status: state.status,
        meetingDetected: state.meetingDetected,
        meetingSessionId: state.meetingSessionId,
        userId: state.userId,
        platform: state.platform,
        authenticated: !!getSessionToken()
      };
    case "SET_AUTH_TOKEN":
      setSessionToken(message.token);
      state.userId = message.userId;
      chrome.storage.local.set({
        sessionToken: message.token,
        userId: message.userId
      });
      if (message.backendUrl) {
        chrome.storage.sync.set({ backendUrl: message.backendUrl });
      }
      return { ok: true };
    case "GET_BACKEND_URL": {
      const data = await new Promise((resolve) => {
        chrome.storage.sync.get({ backendUrl: "" }, resolve);
      });
      return { backendUrl: data.backendUrl || "" };
    }
    case "AUTHENTICATE":
      return handleAuthenticate(message.googleIdToken);
    case "ACK_PROMPT":
      return handleAckPrompt(message);
    case "START_AUDIO_CAPTURE":
      handleStartAudioCapture(message.meetingSessionId);
      return { ok: true };
    case "STOP_AUDIO_CAPTURE":
      chrome.runtime.sendMessage({ type: "STOP_MIC_CAPTURE" }).catch(() => {
      });
      chrome.runtime.sendMessage({ type: "STOP_TAB_CAPTURE" }).catch(() => {
      });
      return { ok: true };
    case "AUDIO_TRANSCRIPT_RESULT":
      broadcastAudioTranscript(message);
      return { ok: true };
    default:
      return { error: "Unknown message type" };
  }
}
async function handleAuthenticate(googleIdToken) {
  try {
    console.log("[GleaMeet] Authenticating with backend...");
    const result = await createSession(googleIdToken);
    state.userId = result.user_id;
    setSessionToken(result.session_token);
    chrome.storage.local.set({
      sessionToken: result.session_token,
      userId: result.user_id
    });
    console.log("[GleaMeet] Auth success, userId:", result.user_id);
    return { ok: true, userId: result.user_id };
  } catch (err) {
    console.error("[GleaMeet] Auth failed:", err.message);
    return { error: err.message };
  }
}
async function handleStartCoaching(message) {
  try {
    if (!getSessionToken()) {
      return { error: "Not authenticated. Please sign in first." };
    }
    const platform = await resolveActiveMeetingPlatform(message.platform);
    if (!platform) {
      return { error: "No supported web meeting tab detected." };
    }
    const request = {
      platform,
      meeting_label: message.meetingLabel || null,
      extension_version: chrome.runtime.getManifest().version,
      consent: message.consent
    };
    const response = await startMeeting(request);
    state.meetingSessionId = response.meeting_session_id;
    state.platform = platform;
    state.meetingDetected = true;
    state.status = "active";
    state.eventBuffer = [];
    restoreTimersForState();
    persistSessionState();
    chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
      for (const tab of tabs) {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            type: "COACHING_STARTED",
            meetingSessionId: response.meeting_session_id,
            userId: state.userId,
            platform
          }).catch(() => {
          });
        }
      }
    });
    broadcastStatus();
    return { status: "active", meetingSessionId: response.meeting_session_id };
  } catch (err) {
    state.status = "error";
    broadcastStatus();
    return { error: err.message };
  }
}
async function handlePauseCoaching() {
  try {
    if (state.eventBuffer.length > 0) await flushEventBuffer().catch(() => {
    });
    clearRuntimeScheduling();
    state.status = "ready";
    persistSessionState();
    broadcastStatus();
    console.log("[GleaMeet] Coaching paused, session preserved:", state.meetingSessionId);
    return { status: "ready" };
  } catch (err) {
    console.error("[GleaMeet] Pause coaching failed:", err);
    return { error: err.message };
  }
}
async function handleStopCoaching() {
  try {
    if (state.meetingSessionId) {
      await flushEventBuffer();
      const result = await endMeeting(state.meetingSessionId);
      clearRuntimeScheduling();
      chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
        for (const tab of tabs) {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, { type: "DISMISS_ALL_PROMPTS" }).catch(() => {
            });
          }
        }
      });
      state.meetingSessionId = null;
      state.status = state.meetingDetected ? "ready" : "off";
      state.eventBuffer = [];
      if (!state.meetingDetected) {
        state.platform = null;
      }
      persistSessionState();
      broadcastStatus();
      return { status: state.status, reportId: result.report_id };
    }
    state.status = state.meetingDetected ? "ready" : "off";
    if (!state.meetingDetected) {
      state.platform = null;
    }
    persistSessionState();
    broadcastStatus();
    return { status: state.status };
  } catch (err) {
    state.status = "error";
    broadcastStatus();
    return { error: err.message };
  }
}
async function handleMeetingEnded() {
  try {
    state.meetingDetected = false;
    if (state.meetingSessionId) {
      await flushEventBuffer().catch(() => {
      });
      await endMeeting(state.meetingSessionId).catch((err) => {
        console.error("[GleaMeet] End meeting on meeting-ended cleanup failed:", err);
      });
    }
    clearRuntimeScheduling();
    state.meetingSessionId = null;
    state.platform = null;
    state.status = "off";
    state.eventBuffer = [];
    persistSessionState();
    broadcastStatus();
    return { status: "off" };
  } catch (err) {
    state.status = "error";
    broadcastStatus();
    return { error: err.message };
  }
}
async function flushEventBuffer() {
  if (state.eventBuffer.length === 0 || !state.meetingSessionId) return;
  const events = [...state.eventBuffer];
  state.eventBuffer = [];
  try {
    const result = await sendEventBatch({
      meeting_session_id: state.meetingSessionId,
      events
    });
    if (result.prompts && result.prompts.length > 0) {
      for (const prompt of result.prompts) {
        broadcastPrompt(prompt);
      }
    }
  } catch (err) {
    state.eventBuffer.unshift(...events);
    console.error("[GleaMeet] Event batch failed:", err);
  }
}
async function pollForPrompts() {
  if (!state.meetingSessionId || state.status !== "active") return;
  try {
    const result = await pollPrompts(state.meetingSessionId);
    for (const prompt of result.prompts) {
      broadcastPrompt(prompt);
    }
  } catch (err) {
    console.error("[GleaMeet] Prompt poll failed:", err);
  }
}
async function handleAckPrompt(message) {
  try {
    const request = {
      prompt_id: message.promptId,
      meeting_session_id: message.meetingSessionId || state.meetingSessionId || "",
      action: message.action,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    await ackPrompt(request);
    return { ok: true };
  } catch (err) {
    console.error("[GleaMeet] Prompt ack failed:", err);
    return { error: err.message };
  }
}
function ensureOffscreenDocument() {
  return chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Audio capture for meeting transcription"
  }).catch(() => {
  });
}
async function handleStartAudioCapture(meetingSessionId) {
  const token = getSessionToken();
  const apiBase = await getApiBase();
  ensureOffscreenDocument().then(() => {
    chrome.runtime.sendMessage({
      type: "START_MIC_CAPTURE",
      meetingSessionId,
      sessionToken: token,
      apiBase
    }).catch(() => {
    });
    getPreferredMeetingTab((tab) => {
      if (!tab?.id) return;
      chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id }, (streamId) => {
        if (chrome.runtime.lastError || !streamId) {
          console.warn("[GleaMeet] Tab capture unavailable:", chrome.runtime.lastError?.message || "missing stream id");
          return;
        }
        chrome.runtime.sendMessage({
          type: "START_TAB_CAPTURE",
          meetingSessionId,
          sessionToken: token,
          apiBase,
          streamId
        }).catch(() => {
        });
      });
    });
  });
}
function broadcastStatus() {
  chrome.runtime.sendMessage({
    type: "STATUS_UPDATE",
    status: state.status,
    meetingDetected: state.meetingDetected,
    meetingSessionId: state.meetingSessionId,
    platform: state.platform
  }).catch(() => {
  });
}
function broadcastPrompt(prompt) {
  chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          type: "SHOW_PROMPT",
          prompt
        }).catch(() => {
        });
      }
    }
  });
}
function broadcastAudioTranscript(message) {
  if (!message.text || !message.stream) return;
  chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          type: "AUDIO_TRANSCRIPT_RESULT",
          text: message.text,
          stream: message.stream,
          startOffsetMs: message.startOffsetMs,
          endOffsetMs: message.endOffsetMs,
          eventTimeMs: message.eventTimeMs
        }).catch(() => {
        });
      }
    }
  });
}
function getPreferredMeetingTab(callback) {
  chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, (tabs) => {
    const preferredTab = tabs.find((tab) => tab.active) ?? tabs[0];
    callback(preferredTab);
  });
}
async function resolveActiveMeetingPlatform(platformHint) {
  if (platformHint) return platformHint;
  if (state.platform) return state.platform;
  const tabs = await new Promise((resolve) => {
    chrome.tabs.query({ url: [...MEETING_TAB_URL_PATTERNS] }, resolve);
  });
  const preferredTab = tabs.find((tab) => tab.active) ?? tabs[0];
  return preferredTab?.url ? detectPlatformFromUrl(preferredTab.url) : null;
}
